module.exports = {
  content: [
    "./views/**/*.ejs",
    "views/**/*.ejs",
    "./public/**/*.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
