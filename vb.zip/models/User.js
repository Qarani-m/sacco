const db = require('./db');
const bcrypt = require('bcrypt');

class User {
    // Create new user
    static async create(userData) {
        const { email, password, full_name, phone_number, role = 'member' } = userData;
        const password_hash = await bcrypt.hash(password, 10);
        
        const query = `
            INSERT INTO users (email, password_hash, full_name, phone_number, role)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id, email, full_name, phone_number, role, is_active, registration_paid, created_at
        `;
        
        const result = await db.query(query, [email, password_hash, full_name, phone_number, role]);
        return result.rows[0];
    }

    // Find user by email
        static async findByEmail(email) {
            console.log(email)
            const query = 'SELECT * FROM users WHERE email = $1';
            console.log(query)
            const result = await db.query(query, [email]);
            return result.rows[0];
        }

    // Find user by ID
    static async findById(id) {
        const query = 'SELECT * FROM users WHERE id = $1';
        const result = await db.query(query, [id]);
        return result.rows[0];
    }

    // Verify password
    static async verifyPassword(plainPassword, hashedPassword) {
        return bcrypt.compare(plainPassword, hashedPassword);
    }

    // Update registration payment status
    static async markRegistrationPaid(userId) {
        const query = `
            UPDATE users 
            SET registration_paid = true, updated_at = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING *
        `;
        const result = await db.query(query, [userId]);
        return result.rows[0];
    }

    // Get all members
    static async getAllMembers(filters = {}) {
        let query = 'SELECT id, email, full_name, phone_number, role, is_active, registration_paid, created_at FROM users WHERE 1=1';
        const params = [];
        let paramCount = 1;

        if (filters.role) {
            query += ` AND role = $${paramCount}`;
            params.push(filters.role);
            paramCount++;
        }

        if (filters.is_active !== undefined) {
            query += ` AND is_active = $${paramCount}`;
            params.push(filters.is_active);
            paramCount++;
        }

        if (filters.registration_paid !== undefined) {
            query += ` AND registration_paid = $${paramCount}`;
            params.push(filters.registration_paid);
            paramCount++;
        }

        query += ' ORDER BY created_at DESC';

        const result = await db.query(query, params);
        return result.rows;
    }

    // Get all admins
    static async getAllAdmins() {
        const query = `
            SELECT id, email, full_name, phone_number, is_active, created_at 
            FROM users 
            WHERE role = 'admin' AND is_active = true
            ORDER BY created_at
        `;
        const result = await db.query(query);
        return result.rows;
    }

    // Update user details
    static async update(userId, updateData) {
        const { full_name, phone_number } = updateData;
        const query = `
            UPDATE users 
            SET full_name = $1, phone_number = $2, updated_at = CURRENT_TIMESTAMP
            WHERE id = $3
            RETURNING id, email, full_name, phone_number, role, is_active, registration_paid
        `;
        const result = await db.query(query, [full_name, phone_number, userId]);
        return result.rows[0];
    }

    // Deactivate user
    static async deactivate(userId) {
        const query = `
            UPDATE users 
            SET is_active = false, updated_at = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING *
        `;
        const result = await db.query(query, [userId]);
        return result.rows[0];
    }

    // Activate user
    static async activate(userId) {
        const query = `
            UPDATE users 
            SET is_active = true, updated_at = CURRENT_TIMESTAMP
            WHERE id = $1
            RETURNING *
        `;
        const result = await db.query(query, [userId]);
        return result.rows[0];
    }

    // Update password
    static async updatePassword(userId, newPassword) {
        const password_hash = await bcrypt.hash(newPassword, 10);
        const query = `
            UPDATE users 
            SET password_hash = $1, updated_at = CURRENT_TIMESTAMP
            WHERE id = $2
            RETURNING id
        `;
        const result = await db.query(query, [password_hash, userId]);
        return result.rows[0];
    }

    // Check if user has active unpaid loan
    static async hasUnpaidLoan(userId) {
        const query = `
            SELECT COUNT(*) as count 
            FROM loans 
            WHERE borrower_id = $1 
            AND status IN ('approved', 'active') 
            AND balance_remaining > 0
        `;
        const result = await db.query(query, [userId]);
        return parseInt(result.rows[0].count) > 0;
    }

    // Get user statistics
    static async getStats(userId) {
        const query = `
            SELECT 
                (SELECT COALESCE(SUM(quantity), 0) FROM shares WHERE user_id = $1 AND status = 'active') as total_shares,
                (SELECT COALESCE(SUM(amount), 0) FROM savings WHERE user_id = $1) as total_savings,
                (SELECT COUNT(*) FROM loans WHERE borrower_id = $1 AND status = 'active') as active_loans,
                (SELECT COALESCE(SUM(balance_remaining), 0) FROM loans WHERE borrower_id = $1 AND status = 'active') as loan_balance
        `;
        const result = await db.query(query, [userId]);
        return result.rows[0];
    }
}

module.exports = User;