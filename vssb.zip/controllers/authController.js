const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const emailService = require('../services/emailService');

exports.showLogin = (req, res) => {
    res.render('auth/login');
};

    exports.login = async (req, res) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                req.flash('error_msg', errors.array()[0].msg);
                return res.redirect('/auth/login');
            }

            const { email, password } = req.body;

            const user = await User.findByEmail(email);

            if (!user) {
                console.error(`email: ${email}, Password: ${password}`);
                req.flash('error_msg', 'Invalid credentials');
                return res.redirect('/auth/login');
            }

            if (!user.is_active) {
                req.flash('error_msg', 'Account is deactivated');
                return res.redirect('/auth/login');
            }

            const isValid = await User.verifyPassword(password, user.password_hash);
            if (!isValid) {
                req.flash('error_msg', 'Invalid credentials');
                return res.redirect('/auth/login');
            }

            const token = jwt.sign(
                { id: user.id, email: user.email, role: user.role, full_name: user.full_name, registration_paid: user.registration_paid },
                process.env.JWT_SECRET || "a strong secret",
                { expiresIn: '7d' }
            );

            // Set JWT in HTTP-only cookie
            res.cookie('token', token, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'Strict',
                maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
            });

            const redirectUrl = user.role === 'admin' ? '/admin/dashboard' : '/members/dashboard';
            
            req.flash('success_msg', 'Login successful!');
            return res.redirect(redirectUrl);

        } catch (error) {
            console.error('Login error:', error);
            req.flash('error_msg', 'Login failed. Please try again.');
            return res.redirect('/auth/login');
        }
    };
exports.showRegister = (req, res) => {
    res.render('auth/register');
};

exports.register = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error_msg', errors.array()[0].msg);
            return res.redirect('/auth/register');
        }

        const { email, password, full_name, phone_number, role } = req.body;

        const existingUser = await User.findByEmail(email);
        if (existingUser) {
            req.flash('error_msg', 'Email already registered');
            return res.redirect('/auth/register');
        }

        const user = await User.create({
            email,
            password,
            full_name,
            phone_number,
            role: role || 'member'
        });

        // Generate verification token
        const { token: verificationToken } = await User.generateVerificationToken(user.id);
        
        // Send verification email
        await emailService.sendVerificationEmail(user.email, verificationToken, user.full_name);

        // Create session token
        const sessionToken = jwt.sign(
            { id: user.id, email: user.email, role: user.role, full_name: user.full_name, registration_paid: user.registration_paid },
            process.env.JWT_SECRET || "a strong secret",
            { expiresIn: '7d' }
        );

        // Set JWT in HTTP-only cookie
        res.cookie('token', sessionToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Strict',
            maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
        });

        req.flash('success_msg', 'Registration successful! Please verify your email.');
        return res.redirect('/auth/verify-email');
    } catch (error) {
        console.error('Registration error:', error);
        req.flash('error_msg', 'Registration failed. Please try again.');
        return res.redirect('/auth/register');
    }
};
exports.logout = (req, res) => {
    // Clear JWT cookie
    res.clearCookie('token', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'Strict'
    });
    
    // Redirect to login page
    res.redirect('/auth/login');
};

exports.showForgotPassword = (req, res) => {
    res.render('auth/forgot-password');
};

exports.forgotPassword = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const { email } = req.body;
        const user = await User.findByEmail(email);

        if (!user) {
            return res.status(404).json({ error: 'Email not found' });
        }

        const resetToken = jwt.sign(
            { id: user.id, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        // TODO: Send email with reset link
        // For now, return token (in production, send via email)
        res.json({
            success: true,
            message: 'Password reset link sent to email',
            resetToken // Remove in production
        });
    } catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({ error: 'Failed to process request' });
    }
};

exports.showResetPassword = (req, res) => {
    res.render('auth/reset-password', { token: req.params.token });
};

exports.resetPassword = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const { token } = req.params;
        const { password } = req.body;

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        await User.updatePassword(decoded.id, password);

        res.json({
            success: true,
            message: 'Password reset successful'
        });
    } catch (error) {
        console.error('Reset password error:', error);
        res.status(400).json({ error: 'Invalid or expired token' });
    }
};

// Show verify email page
exports.showVerifyEmail = (req, res) => {
    res.render('auth/verify-email', { title: 'Verify Email' });
};

// Verify email with token
exports.verifyEmail = async (req, res) => {
    try {
        const { token } = req.params;
        
        // Verify the email
        const user = await User.verifyEmail(token);
        
        // Render success page
        res.render('auth/email-verified', { 
            title: 'Email Verified',
            userName: user.full_name
        });
    } catch (error) {
        console.error('Email verification error:', error);
        res.render('auth/verify-email', {
            title: 'Verify Email',
            error: error.message || 'Invalid or expired verification link'
        });
    }
};

// Resend verification email
exports.resendVerification = async (req, res) => {
    try {
        const { email } = req.body;
        
        const { token, user } = await User.resendVerificationToken(email);
        
        // Send verification email
        await emailService.sendVerificationEmail(user.email, token, user.full_name);
        
        res.json({
            success: true,
            message: 'Verification email sent successfully'
        });
    } catch (error) {
        console.error('Resend verification error:', error);
        res.status(400).json({ 
            error: error.message || 'Failed to resend verification email' 
        });
    }
};