const User = require('../models/User');
const Share = require('../models/Share');
const Loan = require('../models/Loan');
const Savings = require('../models/Savings');
const Notification = require('../models/Notification');
const Transaction = require('../models/Transaction');

const Message = require('../models/Message');

exports.showDashboard = async (req, res) => {
    try {
        const userId = req.user.id;
        
        const stats = await User.getStats(userId);
        const recentTransactions = await Transaction.getByUser(userId);
        const unreadNotifications = await Notification.getUnreadCount(userId);
        const unreadMessages = await Message.getUnreadCount(userId); // Add this
        const activeLoans = await Loan.getByUser(userId, 'active');

        res.render('member/dashboard', {
            title: 'Dashboard',
            user: req.user,
            stats: {
                total_shares: stats.total_shares || 0,
                total_savings: parseFloat(stats.total_savings) || 0,
                active_loans: stats.active_loans || 0,
                loan_balance: parseFloat(stats.loan_balance) || 0
            },
            recent_transactions: recentTransactions.slice(0, 5),
            unreadNotifications: unreadNotifications || 0,
            unreadMessages: unreadMessages || 0, // Add this
            active_loans: activeLoans || []
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).send('Failed to load dashboard');
    }
};

exports.showRegistrationPage = async (req, res) => {
    try {
        res.json({
            success: true,
            registration_fee: 1000,
            message: 'Please pay KSh 1,000 registration fee to access SACCO features'
        });
    } catch (error) {
        console.error('Show registration page error:', error);
        res.status(500).json({ error: 'Failed to load page' });
    }
};

exports.payRegistrationFee = async (req, res) => {
    try {
        const userId = req.user.id;
        const amount = 1000;
        const transactionRef = `REG${Date.now()}${Math.random().toString(36).substr(2, 9)}`;

        const user = await User.findById(userId);
        if (user.registration_paid) {
            return res.status(400).json({ error: 'Registration fee already paid' });
        }

        await Transaction.create({
            user_id: userId,
            amount,
            type: 'registration',
            payment_method: 'mpesa',
            transaction_ref: transactionRef,
            status: 'pending'
        });

        res.json({
            success: true,
            message: 'Check your phone for M-Pesa prompt',
            amount,
            transaction_ref: transactionRef
        });
    } catch (error) {
        console.error('Pay registration fee error:', error);
        res.status(500).json({ error: 'Failed to process payment' });
    }
};

exports.showProfile = async (req, res) => {
    try {
        const userId = req.user.id;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            success: true,
            profile: {
                id: user.id,
                email: user.email,
                full_name: user.full_name,
                phone_number: user.phone_number,
                role: user.role,
                is_active: user.is_active,
                registration_paid: user.registration_paid,
                created_at: user.created_at
            }
        });
    } catch (error) {
        console.error('Show profile error:', error);
        res.status(500).json({ error: 'Failed to load profile' });
    }
};

exports.updateProfile = async (req, res) => {
    try {
        const userId = req.user.id;
        const { full_name, phone_number } = req.body;

        const updatedUser = await User.update(userId, { full_name, phone_number });

        res.json({
            success: true,
            message: 'Profile updated successfully',
            profile: updatedUser
        });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
};

exports.listNotifications = async (req, res) => {
    try {
        const userId = req.user.id;
        const { unread_only } = req.query;

        const notifications = await Notification.getByUser(userId, unread_only === 'true');
        const unreadCount = await Notification.getUnreadCount(userId);

        res.json({
            success: true,
            notifications,
            unread_count: unreadCount
        });
    } catch (error) {
        console.error('List notifications error:', error);
        res.status(500).json({ error: 'Failed to fetch notifications' });
    }
};

exports.markNotificationRead = async (req, res) => {
    try {
        const { notificationId } = req.params;
        await Notification.markAsRead(notificationId);

        res.json({
            success: true,
            message: 'Notification marked as read'
        });
    } catch (error) {
        console.error('Mark notification read error:', error);
        res.status(500).json({ error: 'Failed to mark notification' });
    }
};

exports.viewSavings = async (req, res) => {
    try {
        const userId = req.user.id;
        const currentYear = new Date().getFullYear();

        const yearlyReport = await Savings.getYearlyReport(userId, currentYear);

        res.json({
            success: true,
            savings: {
                previous_years: yearlyReport.previous_savings,
                current_year: yearlyReport.current_year_savings,
                total: yearlyReport.total_savings
            }
        });
    } catch (error) {
        console.error('View savings error:', error);
        res.status(500).json({ error: 'Failed to fetch savings' });
    }
};

exports.uploadDocument = async (req, res) => {
    try {
        const userId = req.user.id;
        const { document_type, file_path } = req.body;

        // Validate document type
        if (!['id_front', 'id_back'].includes(document_type)) {
            return res.status(400).json({ error: 'Invalid document type' });
        }

        const Document = require('../models/Document');
        const document = await Document.create({
            user_id: userId,
            document_type,
            file_path
        });

        // Notify admins
        const admins = await User.getAllAdmins();
        const notifications = admins.map(admin => ({
            user_id: admin.id,
            type: 'document_upload',
            title: 'New Document Upload',
            message: `${req.user.full_name} uploaded ${document_type}`,
            related_entity_type: 'document',
            related_entity_id: document.id
        }));
        await Notification.createBulk(notifications);

        res.json({
            success: true,
            message: 'Document uploaded successfully. Awaiting admin verification',
            document
        });
    } catch (error) {
        console.error('Upload document error:', error);
        res.status(500).json({ error: 'Failed to upload document' });
    }
};

exports.viewDocuments = async (req, res) => {
    try {
        const userId = req.user.id;
        const Document = require('../models/Document');
        const documents = await Document.findByUserId(userId);

        res.json({
            success: true,
            documents
        });
    } catch (error) {
        console.error('View documents error:', error);
        res.status(500).json({ error: 'Failed to fetch documents' });
    }
};